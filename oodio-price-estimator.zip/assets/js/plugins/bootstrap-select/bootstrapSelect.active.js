(function ($) {
    "use strict";
    
    /*Bootstrap Select*/
    if ($('.bSelect').length) {
        $('.bSelect').selectpicker();
    }
    
})(jQuery);